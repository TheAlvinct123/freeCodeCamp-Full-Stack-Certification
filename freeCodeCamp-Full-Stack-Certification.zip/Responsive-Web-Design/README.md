# Responsive Web Design (HTML5 & CSS3)

Projects focused on building user interfaces with semantic HTML5 and modern CSS3. The goal is to create web pages that are accessible, mobile-friendly, and responsive across different screen sizes.
